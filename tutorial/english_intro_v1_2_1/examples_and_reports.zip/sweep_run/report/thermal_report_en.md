# Thermal simulation results report
Software version: 1.2.1; generated UTC: 2026-10-03T16:44:54Z
## Orbit heating and nodal response
- Mean beta angle: 19.46 deg; eclipse fraction: 28.93%.
- RF temperature span: 13.69 K; assumed temperature-induced code-bias span: 2.685 m.
- Estimated forcing-to-RF response lag: 2201 s.
- 1 illumination transitions occurred over this run.
- RF response trails forcing, consistent with thermal inertia but not proof of mechanism.
- The code bias uses assumed thermal sensitivity; it is not measured GNSS error.
- No warmup was used; initial-temperature transients may affect spans and lag.
![scenario](scenario_summary_en.png)
## Sweep coverage and response range
- 6/6 cases completed; beta range -0.0007243 - 30 deg and eclipse fraction 28.10% - 29.75%.
- RF temperature-span range: 12.73 - 15.31 K; code-bias-span range: 2.484 - 3.021 m.
- Largest code-bias span on this grid: 3.021 m at beta -0.0007243 deg.
- Ranges describe this grid; causal effects require controlled comparisons.
![sweep](sweep_summary_en.png)
## Inputs, mesh, material, orbit and attitude
| Section | Field | Value | Unit | Status | Source | Notes |
|---|---|---|---|---|---|---|
| task_input | scenario_name | english_intro_six_cases |  | available | scenario.name |  |
| task_input | duration | 7200 | s | available | scenario.durationS |  |
| task_input | time_step | 60 | s | available | scenario.timeStepS |  |
| task_input | warmup_orbits | 0 | orbit | available | scenario.warmupOrbits |  |
| network | node_count | 11 | node | available | network.nodeNames |  |
| network | node_names | face_+X_forward, face_-X_aft, face_+Y_orbit_left, face_-Y_orbit_right, face_+Z_nadir, face_-Z_zenith, spacecraft_structure, gnss_antenna, gnss_rf_frontend, gnss_oscillator, receiver_digital |  | available | network.nodeNames |  |
| network | conductance_range | [0, 1.4] | W/K | available | network.conductanceWK |  |
| network | internal_power_range | [0, 12] | W | available | network.internalPowerW |  |
| orbit_attitude | epoch_start_utc | 2024-03-20 12:00:00 |  | available | scenario.startEpoch |  |
| orbit_attitude | altitude | 600000 | m | available | scenario.orbit.altitudeM |  |
| orbit_attitude | inclination | 97.6 | deg | available | scenario.orbit.inclinationDeg |  |
| orbit_attitude | attitude_mode | nadir |  | available | scenario.attitude.mode |  |
| orbit_attitude | trajectory_frame | not_recorded |  | not_available | result.orbit/frame | Frame labels are not present in all result producers. |
| telemetry_comparison | status | not_available |  | not_available |  | No telemetry result was supplied; validation was not performed. |
## Energy conservation
| Component | Quantity | Value | Unit | Status |
|---|---|---:|---|---|
| scenario | integratedExternalHeatJ | 8746565.15451 | J | available |
| scenario | integratedInternalHeatJ | 145440 | J | available |
| scenario | integratedRadiatedHeatJ | 10657621.1445 | J | available |
| scenario | integratedBoundaryHeatJ | 0 | J | available |
| scenario | integratedNetHeatJ | -1765615.98999 | J | available |
| scenario | maximumEnergyClosureJ | 2.0008883439e-09 | J | available |
## Numerical diagnostics
- `scenario.absoluteToleranceK` = 1e-06 (available)
- `scenario.relativeTolerance` = 1e-08 (available)
- `scenario.acceptedSteps` = 120 (available)
- `scenario.rejectedSteps` = 0 (available)
- `scenario.maximumAcceptedErrorRatio` = 0.959316703862 (available)
- `scenario.maximumEnergyClosureJ` = 2.0008883439e-09 (available)
## Telemetry comparison
No telemetry comparison was supplied; telemetry validation was not performed.
## Sources and interpretation boundary
- `software`: 1.2.1 (available)
- `scenario`: english_intro_six_cases (available)
Missing modules are marked not_available; this report does not infer contact interfaces, materials, or telemetry conclusions. Without telemetry comparison, the output is simulation-only and must not be described as independent validation.
