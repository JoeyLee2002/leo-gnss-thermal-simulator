# Thermal simulation results report
Software version: 1.2.1; generated UTC: 2026-10-03T16:44:04Z
## Orbit heating and nodal response
- Mean beta angle: 19.46 deg; eclipse fraction: 28.93%.
- RF temperature span: 11.97 K; assumed temperature-induced code-bias span: 2.931 m.
- Estimated forcing-to-RF response lag: 1901 s.
- 1 illumination transitions occurred over this run.
- RF response trails forcing, consistent with thermal inertia but not proof of mechanism.
- The code bias uses assumed thermal sensitivity; it is not measured GNSS error.
![scenario](scenario_summary_en.png)
## Inputs, mesh, material, orbit and attitude
| Section | Field | Value | Unit | Status | Source | Notes |
|---|---|---|---|---|---|---|
| task_input | scenario_name | example_first_simulation |  | available | scenario.name |  |
| task_input | duration | 7200 | s | available | scenario.durationS |  |
| task_input | time_step | 60 | s | available | scenario.timeStepS |  |
| task_input | warmup_orbits | 1 | orbit | available | scenario.warmupOrbits |  |
| network | node_count | 11 | node | available | network.nodeNames |  |
| network | node_names | face_+X_forward, face_-X_aft, face_+Y_orbit_left, face_-Y_orbit_right, face_+Z_nadir, face_-Z_zenith, spacecraft_structure, gnss_antenna, gnss_rf_frontend, gnss_oscillator, receiver_digital |  | available | network.nodeNames |  |
| network | conductance_range | [0, 1.4] | W/K | available | network.conductanceWK |  |
| network | internal_power_range | [0, 12] | W | available | network.internalPowerW |  |
| orbit_attitude | epoch_start_utc | 2024-03-20 12:00:00 |  | available | scenario.startEpoch |  |
| orbit_attitude | altitude | 600000 | m | available | scenario.orbit.altitudeM |  |
| orbit_attitude | inclination | 97.6 | deg | available | scenario.orbit.inclinationDeg |  |
| orbit_attitude | attitude_mode | nadir |  | available | scenario.attitude.mode |  |
| orbit_attitude | trajectory_frame | not_recorded |  | not_available | result.orbit/frame | Frame labels are not present in all result producers. |
| telemetry_comparison | status | not_available |  | not_available |  | No telemetry result was supplied; validation was not performed. |
## Energy conservation
| Component | Quantity | Value | Unit | Status |
|---|---|---:|---|---|
| scenario | integratedExternalHeatJ | 15299145.9027 | J | available |
| scenario | integratedInternalHeatJ | 263004 | J | available |
| scenario | integratedRadiatedHeatJ | 17803004.7067 | J | available |
| scenario | integratedBoundaryHeatJ | 0 | J | available |
| scenario | integratedNetHeatJ | -2240854.80406 | J | available |
| scenario | maximumEnergyClosureJ | 1.70621206053e-09 | J | available |
## Numerical diagnostics
- `scenario.absoluteToleranceK` = 1e-06 (available)
- `scenario.relativeTolerance` = 1e-08 (available)
- `scenario.acceptedSteps` = 217 (available)
- `scenario.rejectedSteps` = 0 (available)
- `scenario.maximumAcceptedErrorRatio` = 0.888328951263 (available)
- `scenario.maximumEnergyClosureJ` = 1.70621206053e-09 (available)
## Telemetry comparison
No telemetry comparison was supplied; telemetry validation was not performed.
## Sources and interpretation boundary
- `software`: 1.2.1 (available)
- `scenario`: example_first_simulation (available)
Missing modules are marked not_available; this report does not infer contact interfaces, materials, or telemetry conclusions. Without telemetry comparison, the output is simulation-only and must not be described as independent validation.
