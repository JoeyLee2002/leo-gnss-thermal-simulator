# Thermal simulation results report
Software version: 1.2.1; generated UTC: 2026-10-03T16:46:33Z
## Orbit heating and nodal response
- Mean beta angle: 19.46 deg; eclipse fraction: 46.96%.
- RF temperature span: 3.971 K; assumed temperature-induced code-bias span: 1.006 m.
- The lag metric is undefined in this run, not zero lag.
- The code bias uses assumed thermal sensitivity; it is not measured GNSS error.
- No warmup was used; initial-temperature transients may affect spans and lag.
![scenario](scenario_summary_en.png)
## Telemetry comparison and evidence boundary
- 3 nodes and 453 scored samples; node RMSE range 0.2093 - 0.4052 K.
- Dataset kind: synthetic_demo_not_flight_data; independence: synthetic_not_independent_validation.
- This is a synthetic-data comparison, not in-flight physical validation.
![telemetry](telemetry_summary_en.png)
## Inputs, mesh, material, orbit and attitude
| Section | Field | Value | Unit | Status | Source | Notes |
|---|---|---|---|---|---|---|
| task_input | scenario_name | example_telemetry_validation |  | available | scenario.name |  |
| task_input | duration | 3600 | s | available | scenario.durationS |  |
| task_input | time_step | 20 | s | available | scenario.timeStepS |  |
| task_input | warmup_orbits | 0 | orbit | available | scenario.warmupOrbits |  |
| network | node_count | 11 | node | available | network.nodeNames |  |
| network | node_names | face_+X_forward, face_-X_aft, face_+Y_orbit_left, face_-Y_orbit_right, face_+Z_nadir, face_-Z_zenith, spacecraft_structure, gnss_antenna, gnss_rf_frontend, gnss_oscillator, receiver_digital |  | available | network.nodeNames |  |
| network | conductance_range | [0, 1.4] | W/K | available | network.conductanceWK |  |
| network | internal_power_range | [0, 12] | W | available | network.internalPowerW |  |
| orbit_attitude | epoch_start_utc | 2024-03-20 12:00:00 |  | available | scenario.startEpoch |  |
| orbit_attitude | altitude | 600000 | m | available | scenario.orbit.altitudeM |  |
| orbit_attitude | inclination | 97.6 | deg | available | scenario.orbit.inclinationDeg |  |
| orbit_attitude | attitude_mode | nadir |  | available | scenario.attitude.mode |  |
| orbit_attitude | trajectory_frame | not_recorded |  | not_available | result.orbit/frame | Frame labels are not present in all result producers. |
| telemetry_comparison | independence | synthetic_not_independent_validation |  | available | telemetry.report.independence |  |
| telemetry_comparison | conclusion | Agreement assessment, not proof of physical correctness. This function does not fit parameters, offsets, gains, or time shifts. Sensor uncertainty, calibration independence, and mission coverage require separate evidence. |  | available | telemetry.report.conclusion |  |
| telemetry_comparison | source | <MATLAB table> |  | available | telemetry.data.source |  |
## Energy conservation
| Component | Quantity | Value | Unit | Status |
|---|---|---:|---|---|
| scenario | integratedExternalHeatJ | 3562714.35363 | J | available |
| scenario | integratedInternalHeatJ | 72720 | J | available |
| scenario | integratedRadiatedHeatJ | 5952604.78757 | J | available |
| scenario | integratedBoundaryHeatJ | 0 | J | available |
| scenario | integratedNetHeatJ | -2317170.43394 | J | available |
| scenario | maximumEnergyClosureJ | 2.29374563787e-09 | J | available |
## Numerical diagnostics
- `scenario.absoluteToleranceK` = 1e-06 (available)
- `scenario.relativeTolerance` = 1e-08 (available)
- `scenario.acceptedSteps` = 180 (available)
- `scenario.rejectedSteps` = 0 (available)
- `scenario.maximumAcceptedErrorRatio` = 0.0320369504171 (available)
- `scenario.maximumEnergyClosureJ` = 2.29374563787e-09 (available)
## Telemetry comparison
| Node | Used samples | RMSE (K) | Assessment |
|---|---:|---:|---|
| gnss_antenna | 151 | 0.40516940555 | comparison_only |
| gnss_rf_frontend | 151 | 0.20928161257 | comparison_only |
| gnss_oscillator | 151 | 0.209927163892 | comparison_only |
## Sources and interpretation boundary
- `software`: 1.2.1 (available)
- `scenario`: example_telemetry_validation (available)
- `telemetry`: <MATLAB table> (available)
Missing modules are marked not_available; this report does not infer contact interfaces, materials, or telemetry conclusions. Without telemetry comparison, the output is simulation-only and must not be described as independent validation.
