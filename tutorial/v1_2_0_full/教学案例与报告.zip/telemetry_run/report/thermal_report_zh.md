# 热仿真结果报告
软件版本：1.2.0；生成时间（UTC）：2026-09-29T09:33:43Z
## 轨道热环境与节点响应
- 平均β角 19.46 度；入影占比 46.96%。
- 射频节点温度跨度 3.971 K；温度诱导码偏差跨度 1.006 m。
- 本次时延指标未定义；不能把它解释成零时延。
- 上述码偏差由设定的温度灵敏度计算，不是实测GNSS误差。
- 未做预热；初始温度暂态可能影响温度跨度和时延。
![scenario](scenario_summary_zh.png)
## 遥测温度对比与证据边界
- 比较 3 个温度节点、453 个评分样本；节点 RMSE 范围 0.2093 - 0.4052 K。
- 数据类型：合成演示数据；独立性：合成数据，非独立验证。
- 本次是合成数据对比，不能作为在轨物理验证。
![telemetry](telemetry_summary_zh.png)
## 输入、网格、材料与轨道姿态
| 类别 | 字段 | 数值 | 单位 | 状态 | 来源 | 备注 |
|---|---|---|---|---|---|---|
| task_input | scenario_name | example_telemetry_validation |  | available | scenario.name |  |
| task_input | duration | 3600 | s | available | scenario.durationS |  |
| task_input | time_step | 20 | s | available | scenario.timeStepS |  |
| task_input | warmup_orbits | 0 | orbit | available | scenario.warmupOrbits |  |
| network | node_count | 11 | node | available | network.nodeNames |  |
| network | node_names | face_+X_forward, face_-X_aft, face_+Y_orbit_left, face_-Y_orbit_right, face_+Z_nadir, face_-Z_zenith, spacecraft_structure, gnss_antenna, gnss_rf_frontend, gnss_oscillator, receiver_digital |  | available | network.nodeNames |  |
| network | conductance_range | [0, 1.4] | W/K | available | network.conductanceWK |  |
| network | internal_power_range | [0, 12] | W | available | network.internalPowerW |  |
| orbit_attitude | epoch_start_utc | 2024-03-20 12:00:00 |  | available | scenario.startEpoch |  |
| orbit_attitude | altitude | 600000 | m | available | scenario.orbit.altitudeM |  |
| orbit_attitude | inclination | 97.6 | deg | available | scenario.orbit.inclinationDeg |  |
| orbit_attitude | attitude_mode | nadir |  | available | scenario.attitude.mode |  |
| orbit_attitude | trajectory_frame | not_recorded |  | not_available | result.orbit/frame | Frame labels are not present in all result producers. |
| telemetry_comparison | independence | synthetic_not_independent_validation |  | available | telemetry.report.independence |  |
| telemetry_comparison | conclusion | Agreement assessment, not proof of physical correctness. This function does not fit parameters, offsets, gains, or time shifts. Sensor uncertainty, calibration independence, and mission coverage require separate evidence. |  | available | telemetry.report.conclusion |  |
| telemetry_comparison | source | <MATLAB table> |  | available | telemetry.data.source |  |
## 能量守恒
| 组件 | 量 | 数值 | 单位 | 状态 |
|---|---|---:|---|---|
| scenario | integratedExternalHeatJ | 3562714.35363 | J | available |
| scenario | integratedInternalHeatJ | 72720 | J | available |
| scenario | integratedRadiatedHeatJ | 5952604.78757 | J | available |
| scenario | integratedBoundaryHeatJ | 0 | J | available |
| scenario | integratedNetHeatJ | -2317170.43394 | J | available |
| scenario | maximumEnergyClosureJ | 2.29374563787e-09 | J | available |
## 数值诊断
- `scenario.absoluteToleranceK` = 1e-06 (available)
- `scenario.relativeTolerance` = 1e-08 (available)
- `scenario.acceptedSteps` = 180 (available)
- `scenario.rejectedSteps` = 0 (available)
- `scenario.maximumAcceptedErrorRatio` = 0.0320369504171 (available)
- `scenario.maximumEnergyClosureJ` = 2.29374563787e-09 (available)
## 遥测对比
| 节点 | 有效样本 | RMSE（K） | 评价 |
|---|---:|---:|---|
| gnss_antenna | 151 | 0.40516940555 | comparison_only |
| gnss_rf_frontend | 151 | 0.20928161257 | comparison_only |
| gnss_oscillator | 151 | 0.209927163892 | comparison_only |
## 来源与结论边界
- `software`: 1.2.0 (available)
- `scenario`: example_telemetry_validation (available)
- `telemetry`: <MATLAB table> (available)
缺失的模块明确标记为 not_available；本报告不从缺失输入推断接触界面、材料或遥测结论。遥测对比若不存在，仅表示仿真结果，不能宣称完成独立验证。
