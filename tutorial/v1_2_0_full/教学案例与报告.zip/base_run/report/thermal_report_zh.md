# 热仿真结果报告
软件版本：1.2.0；生成时间（UTC）：2026-09-29T09:28:41Z
## 轨道热环境与节点响应
- 平均β角 19.46 度；入影占比 28.93%。
- 射频节点温度跨度 11.97 K；温度诱导码偏差跨度 2.931 m。
- 热流至射频响应的估计时延为 1901 s。
- 记录 1 次光照转换；该次数取决于本次时长与轨道条件。
- 射频响应滞后于外部热流，与热惯性相容，但不能单独证明机理。
- 上述码偏差由设定的温度灵敏度计算，不是实测GNSS误差。
![scenario](scenario_summary_zh.png)
## 输入、网格、材料与轨道姿态
| 类别 | 字段 | 数值 | 单位 | 状态 | 来源 | 备注 |
|---|---|---|---|---|---|---|
| task_input | scenario_name | example_first_simulation |  | available | scenario.name |  |
| task_input | duration | 7200 | s | available | scenario.durationS |  |
| task_input | time_step | 60 | s | available | scenario.timeStepS |  |
| task_input | warmup_orbits | 1 | orbit | available | scenario.warmupOrbits |  |
| network | node_count | 11 | node | available | network.nodeNames |  |
| network | node_names | face_+X_forward, face_-X_aft, face_+Y_orbit_left, face_-Y_orbit_right, face_+Z_nadir, face_-Z_zenith, spacecraft_structure, gnss_antenna, gnss_rf_frontend, gnss_oscillator, receiver_digital |  | available | network.nodeNames |  |
| network | conductance_range | [0, 1.4] | W/K | available | network.conductanceWK |  |
| network | internal_power_range | [0, 12] | W | available | network.internalPowerW |  |
| orbit_attitude | epoch_start_utc | 2024-03-20 12:00:00 |  | available | scenario.startEpoch |  |
| orbit_attitude | altitude | 600000 | m | available | scenario.orbit.altitudeM |  |
| orbit_attitude | inclination | 97.6 | deg | available | scenario.orbit.inclinationDeg |  |
| orbit_attitude | attitude_mode | nadir |  | available | scenario.attitude.mode |  |
| orbit_attitude | trajectory_frame | not_recorded |  | not_available | result.orbit/frame | Frame labels are not present in all result producers. |
| telemetry_comparison | status | not_available |  | not_available |  | No telemetry result was supplied; validation was not performed. |
## 能量守恒
| 组件 | 量 | 数值 | 单位 | 状态 |
|---|---|---:|---|---|
| scenario | integratedExternalHeatJ | 15299145.9027 | J | available |
| scenario | integratedInternalHeatJ | 263004 | J | available |
| scenario | integratedRadiatedHeatJ | 17803004.7067 | J | available |
| scenario | integratedBoundaryHeatJ | 0 | J | available |
| scenario | integratedNetHeatJ | -2240854.80406 | J | available |
| scenario | maximumEnergyClosureJ | 1.70621206053e-09 | J | available |
## 数值诊断
- `scenario.absoluteToleranceK` = 1e-06 (available)
- `scenario.relativeTolerance` = 1e-08 (available)
- `scenario.acceptedSteps` = 217 (available)
- `scenario.rejectedSteps` = 0 (available)
- `scenario.maximumAcceptedErrorRatio` = 0.888328951263 (available)
- `scenario.maximumEnergyClosureJ` = 1.70621206053e-09 (available)
## 遥测对比
未提供遥测对比结果；未执行遥测验证。
## 来源与结论边界
- `software`: 1.2.0 (available)
- `scenario`: example_first_simulation (available)
缺失的模块明确标记为 not_available；本报告不从缺失输入推断接触界面、材料或遥测结论。遥测对比若不存在，仅表示仿真结果，不能宣称完成独立验证。
