# Physically Constrained Device Calibration

Outcome: **Review required**. Software version: 1.2.0.

This checks prediction and parameter consistency within a declared scope, not recovery of unknown true hardware parameters. Parameter evidence and limits are user declarations, not independently verified evidence.

## Data and Scope

Whole UTC dates are assigned chronologically to calibration, validation, and final check. Both checks occur after freezing, without selecting weights, bounds, or model structure. Repeated use for tuning makes a check set development data.

Invalid targets remove only their node scores; invalid drivers split segments. No interpolation or filling. Drivers are left-held within valid intervals. Adjacent valid samples within a role carry state across midnight; role changes and invalid data restart segments.

Sensor uncertainty evidence: Synthetic known noise assumption; not a flight sensor calibration..

Per-day/node coverage: at least 1800 s scored duration, 600 s continuous scoring, 0.5 K temperature span and 30 scored samples. Insufficient coverage requires review even with small errors.

Regularization weight: 1; maximum integration step: 10 s; step-halving difference: 2.44427e-12 K.

The loss equally weights date/node standardized mean squared residuals, then adds a prior penalty. It is not an independent-sample likelihood. No parameter confidence intervals are inferred. Data term: 0.012701106; prior term: 0.99733988.

## Parameter Changes

| Node | Parameter | Nominal | Calibrated | Change (%) | Lower | Upper | Prior SD | Near bound |
|---|---|---:|---:|---:|---:|---:|---:|---|
| Custom node: device | Heat capacity (J/K) | 100 | 109.9867 | 9.987 | 80 | 120 | 10 | No |

Unlisted parameters remain fixed. The full table retains units, edge peers, parameter kinds, and evidence. Relative percentages are undefined at zero nominal value.

## Temperature Errors

| Role | Node | Scored samples | Baseline RMSE (K) | Calibrated RMSE (K) |
|---|---|---:|---:|---:|
| Calibration | Custom node: device | 48 | 0.616876 | 0.00225398 |
| Validation | Custom node: device | 48 | 0.661614 | 0.00223258 |
| Final check | Custom node: device | 48 | 0.706547 | 0.00232454 |

The table is sample weighted, not a count of independent replicates. Acceptance checks every predeclared validation/test date and node, not only the pooled mean. See day_metrics.csv.

## Review Flags

- Insufficient scored duration, continuity or temperature variation
- Holdout history not confirmed
- Forcing independence not confirmed
- Parameter evidence not confirmed
- Synthetic data are not flight validation

Training sensitivity rank: 1/1, excluding regularization rows. Full rank does not prove global identifiability. An effective total conductance must not be compared directly with one connector conductance.

If a constrained model cannot explain measurements, inspect heat paths, boundaries, power, sensor mapping, and time. Never automatically relax hardware bounds. Original/calibrated devices, frozen/input snapshots, row audits, and artifact hashes are preserved separately.
