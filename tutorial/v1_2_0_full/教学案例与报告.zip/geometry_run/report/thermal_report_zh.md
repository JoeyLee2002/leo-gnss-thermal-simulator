# 热仿真结果报告
软件版本：1.2.0；生成时间（UTC）：2026-09-29T09:31:17Z
## 轨道热环境与节点响应
- 平均β角 19.46 度；入影占比 0.00%。
- 射频节点温度跨度 1.651 K；温度诱导码偏差跨度 0.5178 m。
- 本次时延指标未定义；不能把它解释成零时延。
- 几乎没有入影，不能据此分析入影后的热滞后。
- 上述码偏差由设定的温度灵敏度计算，不是实测GNSS误差。
- 未做预热；初始温度暂态可能影响温度跨度和时延。
![scenario](scenario_summary_zh.png)
## 三维温度与耦合诊断
- 表面 6 个面片；计算温度范围 284.1 - 301.3 K。
- 体网格 5 个节点；计算温度范围 293.1 - 294.7 K。
- 表面至体边界热流映射的最大闭合差 1.137e-13 W。
- 当前是单向表面至体耦合；表面温度不反馈到体求解。
- 温度范围是数值结果；材料和接触边界仍需按目标卫星核实。
![geometry](geometry_summary_zh.png)
## 输入、网格、材料与轨道姿态
| 类别 | 字段 | 数值 | 单位 | 状态 | 来源 | 备注 |
|---|---|---|---|---|---|---|
| task_input | scenario_name | example_surface_volume_coupled |  | available | scenario.name |  |
| task_input | duration | 600 | s | available | scenario.durationS |  |
| task_input | time_step | 30 | s | available | scenario.timeStepS |  |
| task_input | warmup_orbits | 0 | orbit | available | scenario.warmupOrbits |  |
| network | node_count | 11 | node | available | network.nodeNames |  |
| network | node_names | face_+X_forward, face_-X_aft, face_+Y_orbit_left, face_-Y_orbit_right, face_+Z_nadir, face_-Z_zenith, spacecraft_structure, gnss_antenna, gnss_rf_frontend, gnss_oscillator, receiver_digital |  | available | network.nodeNames |  |
| network | conductance_range | [0, 1.4] | W/K | available | network.conductanceWK |  |
| network | internal_power_range | [0, 12] | W | available | network.internalPowerW |  |
| surface_mesh | face_count | 6 | face | available | surface.mesh.faces |  |
| surface_mesh | total_area | 4.09807621135 | m^2 | available | surface.mesh.faceAreasM2 |  |
| surface_radiation | view_factor_source | differential_area_centroid |  | available | surface.numerics.viewFactorDiagnostics |  |
| surface_radiation | thermal_parameter_provenance | example_declared_coupled_surface_inputs |  | available | surface.mesh.thermalParameterProvenance |  |
| surface_radiation | radiation_history | stored |  | available | surface result fields |  |
| volume_mesh | node_count | 5 | node | available | volume.mesh.nodesM |  |
| volume_mesh | tetrahedron_count | 2 | tetrahedron | available | volume.mesh.tetrahedra |  |
| volume_conduction | formulation | linear_tetrahedron_galerkin_lumped_capacity |  | available | volume.model.formulation |  |
| volume_conduction | conductivity_range | [1, 1] | W/(m K) | available | volume.model.elementConductivityWmK |  |
| volume_conduction | density_range | [1000, 1000] | kg/m^3 | available | volume.model.elementDensityKgM3 |  |
| volume_conduction | specific_heat_range | [1000, 1000] | J/(kg K) | available | volume.model.elementSpecificHeatJkgK |  |
| orbit_attitude | epoch_start_utc | 2024-03-20 12:00:00 |  | available | scenario.startEpoch |  |
| orbit_attitude | altitude | 600000 | m | available | scenario.orbit.altitudeM |  |
| orbit_attitude | inclination | 97.6 | deg | available | scenario.orbit.inclinationDeg |  |
| orbit_attitude | attitude_mode | nadir |  | available | scenario.attitude.mode |  |
| orbit_attitude | trajectory_frame | not_recorded |  | not_available | result.orbit/frame | Frame labels are not present in all result producers. |
| surface_volume_coupling | input_kind | face_power_w |  | available | coupling.inputKind |  |
| surface_volume_coupling | boundary_matching | exact_boundary_triangle_equal_shape_weights |  | available | coupling.method |  |
| surface_volume_coupling | matched_boundary_faces | 6 | face | available | coupling.matchedBoundaryFaceCount |  |
| surface_volume_coupling | maximum_absolute_closure | 1.13686837722e-13 | W | available | coupling.maximumAbsoluteClosureW |  |
| surface_volume_coupling | contact_pair_count | 1 | pair | available | volume.contactDiagnostics.pairCount |  |
| telemetry_comparison | status | not_available |  | not_available |  | No telemetry result was supplied; validation was not performed. |
## 能量守恒
| 组件 | 量 | 数值 | 单位 | 状态 |
|---|---|---:|---|---|
| scenario | integratedExternalHeatJ | 1020270.22978 | J | available |
| scenario | integratedInternalHeatJ | 12120 | J | available |
| scenario | integratedRadiatedHeatJ | 1214267.07738 | J | available |
| scenario | integratedBoundaryHeatJ | 0 | J | available |
| scenario | integratedNetHeatJ | -181876.847596 | J | available |
| scenario | maximumEnergyClosureJ | 9.31322574615e-10 | J | available |
| surface | integratedExternalHeatJ | 562141.538167 | J | available |
| surface | maximumEnergyClosureJ | 1.053649612e-09 | J | available |
| volume | integratedNodalPowerJ | 562141.538167 | J | available |
| volume | maximum_linear_residual | 4.65661287308e-10 | solver units | diagnostic_only |
## 数值诊断
- `scenario.absoluteToleranceK` = 1e-06 (available)
- `scenario.relativeTolerance` = 1e-08 (available)
- `scenario.acceptedSteps` = 20 (available)
- `scenario.rejectedSteps` = 0 (available)
- `scenario.maximumAcceptedErrorRatio` = 0.000225261277739 (available)
- `scenario.maximumEnergyClosureJ` = 9.31322574615e-10 (available)
- `surface.acceptedSteps` = 20 (available)
- `surface.maximumEnergyClosureJ` = 1.053649612e-09 (available)
- `volume.theta` = 1 (available)
- `volume.fixedNodeCount` = 1 (available)
- `volume.acceptedSteps` = 20 (available)
- `volume.maximumLinearResidual` = 4.65661287308e-10 (available)
## 遥测对比
未提供遥测对比结果；未执行遥测验证。
## 来源与结论边界
- `software`: 1.2.0 (available)
- `scenario`: example_surface_volume_coupled (available)
- `surface_mesh`: H:\paper\leo-gnss-thermal-simulator\examples\assets\example_coupled_surface.obj (available)
- `volume_mesh`: H:\paper\leo-gnss-thermal-simulator\examples\assets\example_two_tetrahedra.msh (available)
缺失的模块明确标记为 not_available；本报告不从缺失输入推断接触界面、材料或遥测结论。遥测对比若不存在，仅表示仿真结果，不能宣称完成独立验证。
