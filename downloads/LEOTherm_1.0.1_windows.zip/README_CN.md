# Windows 独立版（v1.0.1）

独立版供没有 MATLAB 许可证的用户使用。它仍需要免费的 **MATLAB Runtime R2021b**；
Runtime 与完整 MATLAB 不是同一个软件。此版本只在 Windows 上构建和测试。

## 用户安装

1. 从 MathWorks 官方网站安装 MATLAB Runtime R2021b：
   https://www.mathworks.com/products/compiler/matlab-runtime.html
2. 从 GitHub Release 下载 `LEOTherm_1.0.1_windows.zip` 并解压。
3. 启动 `LEOTherm.exe`。第一次启动可能需要等待 Runtime 解压缓存。
4. 在“快速开始”选择任务模板并运行，在“结果与导出”生成 PDF。

用户不需要购买或安装 MATLAB。Runtime 的版本必须与编译软件使用的 R2021b 匹配。
此包不是完全无依赖程序，也不是 macOS/Linux 安装包。

## 开发者构建

在装有 MATLAB R2021b 和 MATLAB Compiler 的 Windows 机器执行：

```matlab
cd('项目所在目录')
addpath('tools')
artifact = build_standalone
archive = package_standalone
```

可执行文件位于 `results/standalone_v1_0_1/LEOTherm.exe`。
待上传的 GitHub Release 压缩包位于 `results/LEOTherm_1.0.1_windows.zip`。
构建会嵌入 `VERSION`、`src/`、`templates/` 和 `examples/`。
不要将本机绝对路径作为任务模板中的输入；用户外部文件通过 GUI 选择。

构建后执行 `LEOTherm.exe --smoke 新目录路径`，检查新目录内的
`standalone_smoke_status.txt` 和 `thermal_report_zh.pdf`。
还可执行 `LEOTherm.exe --gui-smoke 另一个新目录路径`，检查 GUI 导出链路的
`standalone_gui_status.txt` 与 `report/thermal_report_zh.pdf`。
正式发布还需在**未安装 MATLAB**、只安装 Runtime 的 Windows 机器上复验。
