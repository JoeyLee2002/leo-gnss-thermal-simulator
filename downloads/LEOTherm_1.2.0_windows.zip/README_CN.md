# Windows 独立版（v1.2.0）

独立版不需要 MATLAB 许可证，但需要免费的 **MATLAB Runtime R2021b**。目前只提供 Windows 构建。

1. 从 [MathWorks MATLAB Runtime 页面](https://www.mathworks.com/products/compiler/matlab-runtime.html) 安装 R2021b。
2. 下载并解压 `LEOTherm_1.2.0_windows.zip`。
3. 双击 `LEOTherm.exe`。首次启动可能需要等待 Runtime 初始化。
4. 在“仿真”页勾选需要的阶段，检查任务后运行。未勾选的扫描、三维、遥测和标定无需填写输入。
5. 到“结果与导出”打开本次 PDF。报告按实际完成的阶段增加定量分析和图表，未运行阶段只在验收页标为“跳过”。

输入、结果、报告和运行状态均保存在本次任务目录。中文版视频展示 v1.1.0 的界面流程；v1.2.0 的报告页已有改版，见[报告说明](任务分析报告_v1.2.0.md)。

正式跨机器发布前，仍需在仅安装 Runtime、没有 MATLAB 的 Windows 机器上复验。
