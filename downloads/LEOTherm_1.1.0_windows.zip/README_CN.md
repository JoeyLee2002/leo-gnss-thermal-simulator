# Windows 独立版（v1.1.0）

独立版不需要 MATLAB 许可证，但需要免费的 **MATLAB Runtime R2021b**。目前只提供 Windows 构建。

1. 从 [MathWorks MATLAB Runtime 页面](https://www.mathworks.com/products/compiler/matlab-runtime.html) 安装 R2021b。
2. 下载并解压 `LEOTherm_1.1.0_windows.zip`。
3. 双击 `LEOTherm.exe`。首次启动可能需要等待 Runtime 初始化。
4. 按压缩包内的 `TASK_GUIDE_CN.md` 选择模板、勾选需要的阶段、检查并运行；最后打开本次 PDF。

勾选项默认全部关闭。没有遥测和网格的新用户可只运行基础节点热仿真。每次任务在新目录保留输入快照、运行状态和报告。

源码开发者使用 MATLAB R2021b 和 MATLAB Compiler，依次运行 `build_standalone` 与 `package_standalone`。构建后可用 `LEOTherm.exe --smoke 新目录` 检查基础流水线，或用 `LEOTherm.exe --gui-smoke 新目录` 检查 GUI 到报告的流水线。正式跨机器发布前，应在仅安装 Runtime、未安装 MATLAB 的 Windows 机器上复验。
